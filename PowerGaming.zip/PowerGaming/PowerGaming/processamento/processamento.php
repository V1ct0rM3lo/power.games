<?php

session_start();
require_once("../model/Produto.php");
require_once("../model/Cliente.php");
require_once("../controller/Controlador.php");

$controlador = new Controlador();

// Função para conectar ao banco de dados
function conectarBanco()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "powergames";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Falha na conexão: " . $conn->connect_error);
    }

    return $conn;
}

// Função para verificar login
function verificarLogin($email, $senha)
{
    $controlador = new Controlador();

    // Verifica se o login é para o administrador
    if ($email === "administrador@hotmail.com" && $senha === "admin123") {
        $_SESSION['estaLogado'] = true;
        header('Location: ../view/homeAdmin.php'); // Redireciona para a página inicial do administrador
        die();
    }

    // Verifica login para usuários comuns
    if ($controlador->verificarLogin($email, $senha)) {
        $_SESSION['estaLogado'] = true; // Apenas se não for admin
        header('Location: ../view/homeUsuario.php'); // Redireciona para a página inicial do usuário
        die();
    } else {
        header('Location: ../view/login.php?error=invalid'); // Adiciona um parâmetro de erro na URL
        die();
    }
}

// Função para cadastrar cliente
function cadastrarCliente($controlador, $nome, $sobrenome, $cpf, $telefone, $email, $senha)
{
    if ($controlador->cadastrarCliente($nome, $sobrenome, $cpf, $telefone, $email, $senha)) {
        header('Location: ../view/login.php');
    } else {
        echo "Erro ao cadastrar cliente";
    }
    die();
}

// Função para cadastrar produto
function cadastrarProduto($controlador, $nome, $fabricante, $descricao, $valor, $imagem)
{
    $diretorioUpload = "../uploads/";

    if (!is_dir($diretorioUpload)) {
        if (!mkdir($diretorioUpload, 0755, true)) {
            echo "Erro ao criar o diretório de uploads.";
            die();
        }
    }

    $caminhoArquivo = $diretorioUpload . basename($imagem['name']);

    if (move_uploaded_file($imagem['tmp_name'], $caminhoArquivo)) {
        if ($controlador->cadastrarProduto($nome, $fabricante, $descricao, $valor, $caminhoArquivo)) {
            header('Location: ../view/home.php');
            die();
        } else {
            echo "Erro ao cadastrar produto";
        }
    } else {
        echo "Erro ao fazer upload do arquivo.";
        die();
    }
}

// Verificar login
if (!empty($_POST['inputEmailLog']) && !empty($_POST['inputSenhaLog'])) {
    verificarLogin($_POST['inputEmailLog'], $_POST['inputSenhaLog']);
} else if (!empty($_POST['inputNome']) && !empty($_POST['inputSobrenome']) &&
    !empty($_POST['inputCPF']) && !empty($_POST['inputTelefone']) &&
    !empty($_POST['inputEmail']) && !empty($_POST['inputSenha'])) {

    // Cadastro de cliente
    $nome = $_POST['inputNome'];
    $sobrenome = $_POST['inputSobrenome'];
    $cpf = $_POST['inputCPF'];
    $telefone = $_POST['inputTelefone'];
    $email = $_POST['inputEmail'];
    $senha = $_POST['inputSenha'];

    cadastrarCliente($controlador, $nome, $sobrenome, $cpf, $telefone, $email, $senha);
} else if (!empty($_POST['inputNomeProd']) && !empty($_POST['inputFabricanteProd']) &&
    !empty($_POST['inputDescricaoProd']) && !empty($_POST['inputValorProd']) &&
    isset($_FILES['inputImagemProd']) && !empty($_FILES['inputImagemProd']['name'])) {

    // Cadastro de produto
    cadastrarProduto($controlador, $_POST['inputNomeProd'], $_POST['inputFabricanteProd'], $_POST['inputDescricaoProd'], $_POST['inputValorProd'], $_FILES['inputImagemProd']);
} else {
    echo "Todos os campos do formulário são obrigatórios, incluindo a imagem.";
    die();
}

?>
