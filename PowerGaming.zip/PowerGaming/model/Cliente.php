<?php

class Cliente
{
    protected $nome;
    protected $sobrenome;
    protected $cpf;
    protected $telefone;
    protected $email;
    protected $senha;

    public function __construct($nome, $sobrenome, $cpf, $telefone, $email, $senha)
    {
        $this->nome = $nome;
        $this->sobrenome = $sobrenome;
        $this->cpf = $cpf;
        $this->telefone = $telefone;
        $this->email = $email;
        $this->senha = $senha;
    }

    public function get_Nome()
    {
        return $this->nome;
    }

    public function get_Sobrenome()
    {
        return $this->sobrenome;
    }

    public function get_Cpf()
    {
        return $this->cpf;
    }

    public function get_Telefone()
    {
        return $this->telefone;
    }

    public function get_Email()
    {
        return $this->email;
    }

    public function get_Senha()
    {
        return $this->senha;
    }
}

?>
