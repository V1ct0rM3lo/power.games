<?php

interface Fabrica
{
    public function criarObjeto();
}
